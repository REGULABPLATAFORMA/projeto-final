import { ReactNode, useEffect, useState } from "react"
import { Star, StarOff, Copy, Edit } from "lucide-react"

interface FeatureCardProps {
  title: string
  icon?: ReactNode
  description?: string
  children?: ReactNode
}

export function FeatureCard({ title, icon, description, children }: FeatureCardProps) {
  const [favorited, setFavorited] = useState(false)
  const [copied, setCopied] = useState(false)

  useEffect(() => {
    try {
      const saved = localStorage.getItem("favorites")
      if (saved) {
        const favorites: string[] = JSON.parse(saved)
        if (favorites.includes(title)) {
          setFavorited(true)
        }
      }
    } catch (error) {
      console.error("Erro ao carregar favoritos:", error)
    }
  }, [title])

  const handleCopy = () => {
    if (typeof navigator !== "undefined" && navigator.clipboard) {
      navigator.clipboard.writeText(title).then(() => {
        setCopied(true)
        setTimeout(() => setCopied(false), 2000)
      }).catch((err) => console.error("Erro ao copiar:", err))
    }
  }

  const toggleFavorite = () => {
    try {
      const saved = localStorage.getItem("favorites")
      let favorites: string[] = saved ? JSON.parse(saved) : []

      if (favorited) {
        favorites = favorites.filter((item) => item !== title)
      } else {
        favorites.push(title)
      }

      localStorage.setItem("favorites", JSON.stringify(favorites))
      setFavorited(!favorited)
    } catch (error) {
      console.error("Erro ao salvar favoritos:", error)
    }
  }

  return (
    <div className="relative rounded-lg border border-gray-200 bg-white p-5 shadow-sm transition-shadow hover:shadow-md">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          {icon && <div className="text-red-700">{icon}</div>}
          <h3 className="text-lg font-bold text-red-700">{title}</h3>
        </div>

        <div className="flex gap-2 text-gray-500">
          <button onClick={handleCopy} title="Copiar título" className="hover:text-red-600">
            <Copy size={18} />
          </button>
          <button title="Editar" className="hover:text-red-600">
            <Edit size={18} />
          </button>
          <button onClick={toggleFavorite} title="Favoritar">
            {favorited ? (
              <Star className="text-yellow-500 transition-transform scale-110" size={18} />
            ) : (
              <StarOff size={18} />
            )}
          </button>
        </div>
      </div>

      {description && <p className="text-sm text-gray-600 mb-3">{description}</p>}

      <div>{children}</div>

      {copied && (
        <span className="absolute bottom-2 right-3 text-xs text-green-600 animate-pulse">
          Copiado!
        </span>
      )}
    </div>
  )
}
