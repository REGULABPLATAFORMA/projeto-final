"use client"

export default function DashboardPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-red-700">Bem-vindo à REGULAB</h1>
      <p className="text-gray-600">
        Esta é sua plataforma completa para regularização fundiária. Utilize o menu ao lado para acessar os
        recursos disponíveis.
      </p>

      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        <div className="rounded-lg border border-gray-200 bg-white p-4 shadow">
          <h3 className="text-lg font-semibold text-red-700">Modelos Disponíveis</h3>
          <p className="text-sm text-gray-500">Baixe documentos técnicos e jurídicos prontos para uso.</p>
        </div>
        <div className="rounded-lg border border-gray-200 bg-white p-4 shadow">
          <h3 className="text-lg font-semibold text-red-700">Profissionais Credenciados</h3>
          <p className="text-sm text-gray-500">Encontre engenheiros, advogados e topógrafos por região.</p>
        </div>
        <div className="rounded-lg border border-gray-200 bg-white p-4 shadow">
          <h3 className="text-lg font-semibold text-red-700">Downloads</h3>
          <p className="text-sm text-gray-500">Histórico de arquivos acessados pela sua conta.</p>
        </div>
      </div>
    </div>
  )
}
